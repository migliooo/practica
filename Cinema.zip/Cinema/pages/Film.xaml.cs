﻿using Cinema.classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Cinema.pages
{
    /// <summary>
    /// Логика взаимодействия для Film.xaml
    /// </summary>
    public partial class Film : Page
    {
        public Film()
        {
            InitializeComponent();

            DGrid.ItemsSource = KinoEntities.GetEntities().Kino.ToList();

            CmbFiltrGenre.ItemsSource = KinoEntities.GetEntities().Genre.ToList();
            CmbFiltrGenre.SelectedValuePath = "id";
            CmbFiltrGenre.DisplayMemberPath = "genre1";

            CountAutoLabel.Content = "Общее количество фильмов в кинотеатре: " + DGrid.Items.Count;
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new FilmAdd((sender as Button).DataContext as Kino));
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGrid.ItemsSource = KinoEntities.GetEntities().Kino.
                OrderBy(x => x.title).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGrid.ItemsSource = KinoEntities.GetEntities().Kino.
                OrderByDescending(x => x.title).ToList();
        }

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string search = TxtSearch.Text;
            if (TxtSearch.Text != null)
                DGrid.ItemsSource = KinoEntities.GetEntities().Kino.
                    Where(x => x.title.Contains(search)).ToList();
        }

        private void CmbFiltrGenre_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGenre.SelectedValue);
            DGrid.ItemsSource = KinoEntities.GetEntities().Kino.Where(x => x.genre == id).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGrid.ItemsSource = KinoEntities.GetEntities().Kino.ToList();

            CountAutoLabel.Content = "Общее количество фильмов в кинотеатре: " + DGrid.Items.Count;
        }

        private void BtnPrint_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnWord_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var filmsForRemoving = DGrid.SelectedItems.Cast<Kino>().ToList();
            if (MessageBox.Show($"Удалить {filmsForRemoving.Count()} фильмов?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    KinoEntities.GetEntities().Kino.RemoveRange(filmsForRemoving);
                    KinoEntities.GetEntities().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGrid.ItemsSource = KinoEntities.GetEntities().Kino.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }

            CountAutoLabel.Content = "Общее количество фильмов в кинотеатре:: " + DGrid.Items.Count;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new FilmAdd(null));
        }
    }
}
