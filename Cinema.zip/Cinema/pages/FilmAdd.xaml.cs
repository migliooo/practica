﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Cinema.classes;

namespace Cinema.pages
{
    /// <summary>
    /// Логика взаимодействия для FilmAdd.xaml
    /// </summary>
    public partial class FilmAdd : Page
    {

        private Kino _currentFilm = new Kino();

        public FilmAdd(Kino selectedFilm)
        {
            InitializeComponent();

            CmbClassAuto.ItemsSource = KinoEntities.GetEntities().Director.ToList();
            CmbClassAuto.SelectedValuePath = "id";
            CmbClassAuto.DisplayMemberPath = "Second_name";

            CmbColor.ItemsSource = KinoEntities.GetEntities().Genre.ToList();
            CmbColor.SelectedValuePath = "id";
            CmbColor.DisplayMemberPath = "genre1";

            if (selectedFilm != null)
                _currentFilm = selectedFilm;
            //создаем контекст
            DataContext = _currentFilm;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentFilm.id == 0)
                KinoEntities.GetEntities().Kino.Add(_currentFilm); //добавить в контекст
            try
            {
                KinoEntities.GetEntities().SaveChanges(); // сохранить изменения
                MessageBox.Show("Данные сохранены");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void genre_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new GenreInfo());
        }

        private void director_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new DirectorInfo());
        }
    }
}
